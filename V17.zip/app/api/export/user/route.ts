import { NextRequest } from "next/server";
import { supabaseAdmin } from "@/lib/supabase";
import { json } from "@/lib/http";
import { toDate, ceilMinutesTo30 } from "@/lib/time";

type Ev = {
  user_id: string;
  site_id: string | null;
  type: "IN" | "OUT" | "OFFSITE";
  server_time: string;
  day_local: string | null;

  note_work: string | null;
  km: number | null;

  offsite_reason: string | null;
  offsite_hours: number | null;

  material_desc: string | null;
  material_amount: number | null;

  programming_hours: number | null;
  programming_note: string | null;

  is_paid: boolean;
};

type Rates = { hourly: number; km: number; prog: number };

function toNum(v: any, d = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
}

/**
 * Per-user export for Google Sheets.
 * Security model: long random token stored on user (users.export_token).
 * Example:
 *   /api/export/user?token=...&from=...&to=...
 */
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const token = url.searchParams.get("token") || "";
  const from = url.searchParams.get("from") || new Date(Date.now() - 14 * 86400000).toISOString();
  const to = url.searchParams.get("to") || new Date().toISOString();

  if (!token || token.length < 16) return json({ error: "Chybí token." }, { status: 400 });

  const db = supabaseAdmin();

  // Find user by export_token
  const { data: user, error: uErr } = await db
    .from("users")
    .select("id,name,role,hourly_rate,km_rate,is_programmer,programming_rate,export_token")
    .eq("export_token", token)
    .maybeSingle();

  if (uErr) return json({ error: "DB chyba (user)." }, { status: 500 });
  if (!user) return json({ error: "Neplatný token." }, { status: 401 });

  const user_id = (user as any).id as string;
  const user_name = (user as any).name as string;

  const defHourly = toNum((user as any).hourly_rate, 0);
  const defaultRate: Rates = {
    hourly: defHourly,
    km: toNum((user as any).km_rate, 0),
    // fallback: when programming_rate not set -> use hourly
    prog: toNum((user as any).programming_rate, defHourly),
  };

  // rates per user+site
  const { data: usrSiteRates, error: rErr } = await db
    .from("user_site_rates")
    .select("user_id,site_id,hourly_rate,km_rate,programming_rate")
    .eq("user_id", user_id);

  if (rErr) return json({ error: "DB chyba (rates)." }, { status: 500 });

  const rateMap = new Map<string, Rates>();
  for (const r of usrSiteRates || []) {
    const hourly = toNum((r as any).hourly_rate, defaultRate.hourly);
    rateMap.set(`${(r as any).user_id}__${(r as any).site_id}`, {
      hourly,
      km: toNum((r as any).km_rate, defaultRate.km),
      // fallback: if per-site programming_rate missing -> use per-site hourly
      prog: toNum((r as any).programming_rate, hourly),
    });
  }

  const getRate = (site_id: string | null): Rates => {
    if (site_id) {
      const r = rateMap.get(`${user_id}__${site_id}`);
      if (r) return r;
    }
    return defaultRate;
  };

  // sites map (names)
  const { data: sites, error: sErr } = await db.from("sites").select("id,name");
  if (sErr) return json({ error: "DB chyba (sites)." }, { status: 500 });
  const siteName = new Map<string, string>();
  for (const s of sites || []) siteName.set((s as any).id, (s as any).name);

  // events (only this user) – include programming_* fields
  const { data: evs, error } = await db
    .from("attendance_events")
    .select(
      "user_id,site_id,type,server_time,day_local,note_work,km,offsite_reason,offsite_hours,material_desc,material_amount,programming_hours,programming_note,is_paid"
    )
    .eq("user_id", user_id)
    .gte("server_time", from)
    .lte("server_time", to)
    .order("server_time", { ascending: true });

  if (error) return json({ error: "DB chyba (events)." }, { status: 500 });

  const events = (evs || []) as Ev[];

  // group by day_local
  const byDay = new Map<string, Ev[]>();
  for (const e of events) {
    const day = e.day_local || e.server_time.slice(0, 10);
    byDay.set(day, [...(byDay.get(day) || []), e]);
  }

  const rows: any[] = [];

  
for (const [day, list] of byDay.entries()) {
  // Aggregate per action (site) so that one day with two actions becomes two rows.
  type Acc = {
    action: string;
    site_id: string | null;
    sitesUsed: Set<string>;
    workNotes: string[];
    offsiteNotes: string[];
    materialNotes: string[];
    hoursRounded: number;
    hoursRaw: number;
    progHours: number;
    workPay: number;
    km: number;
    travelPay: number;
    material: number;
    paid: boolean;
  };

  const accMap = new Map<string, Acc>();

  const getAcc = (site_id: string | null) => {
    const action = site_id ? (siteName.get(site_id) || site_id) : "Mimo lokaci";
    const key = `${site_id || "OFFSITE"}__${action}`;
    const existing = accMap.get(key);
    if (existing) return existing;
    const a: Acc = {
      action,
      site_id,
      sitesUsed: new Set<string>(),
      workNotes: [],
      offsiteNotes: [],
      materialNotes: [],
      hoursRounded: 0,
      hoursRaw: 0,
      progHours: 0,
      workPay: 0,
      km: 0,
      travelPay: 0,
      material: 0,
      paid: true,
    };
    if (site_id) a.sitesUsed.add(action);
    accMap.set(key, a);
    return a;
  };

  // IN->OUT segments (action is taken from IN.site_id; fallback OUT.site_id)
  let lastIn: { t: Date; site_id: string | null } | null = null;

  for (const e of list) {
    if (e.type === "IN") {
      lastIn = { t: toDate(e.server_time), site_id: e.site_id };
      continue;
    }

    if (e.type === "OUT" && lastIn) {
      const out = toDate(e.server_time);

      const minutesRaw = Math.max(0, Math.round((out.getTime() - lastIn.t.getTime()) / 60000));
      const minutesRounded = ceilMinutesTo30(minutesRaw);

      const hRaw = minutesRaw / 60;
      const h = minutesRounded / 60;

      const segSiteId = lastIn.site_id || e.site_id || null;
      const a = getAcc(segSiteId);
      const r = getRate(segSiteId);

      const progH = Math.max(0, Math.min(h, toNum((e as any).programming_hours, 0)));
      const siteH = Math.max(0, h - progH);

      a.hoursRounded += h;
      a.hoursRaw += hRaw;
      a.progHours += progH;
      a.workPay += siteH * r.hourly + progH * r.prog;

      // km + travel pay belongs to this OUT (same action)
      const k = toNum(e.km, 0);
      a.km += k;
      a.travelPay += k * r.km;

      // material refund belongs to this OUT
      const mat = toNum(e.material_amount, 0);
      a.material += mat;
      if (mat > 0) {
        const desc = (e.material_desc || "").trim();
        a.materialNotes.push(`${desc ? desc + " – " : ""}${mat} Kč`);
      }

      if (e.note_work) a.workNotes.push(e.note_work.trim());

      a.paid = a.paid && !!e.is_paid;
      lastIn = null;
      continue;
    }

    if (e.type === "OFFSITE") {
      const a = getAcc(e.site_id || null);
      const r = getRate(e.site_id || null);
      const h = toNum(e.offsite_hours, 0);
      if (h > 0) {
        a.hoursRounded += h;
        a.workPay += h * r.hourly;
      }
      if (e.offsite_reason) a.offsiteNotes.push(`${e.offsite_reason.trim()} (${h} h)`);
      a.paid = a.paid && !!e.is_paid;
      continue;
    }
  }

  // Emit rows for this day (one per action)
  for (const a of accMap.values()) {
    const siteHours = Math.max(0, a.hoursRounded - a.progHours);
    const totalToPay = a.workPay + a.travelPay + a.material;

    rows.push({
      user_id,
      user_name,
      day,

      action: a.action, // single action label for reports
      sites: Array.from(a.sitesUsed),
      work_notes: a.workNotes,
      offsite_notes: a.offsiteNotes,
      material_notes: a.materialNotes,

      hours_raw: Math.round(a.hoursRaw * 100) / 100,
      hours_rounded: Math.round(a.hoursRounded * 100) / 100,
      prog_hours: Math.round(a.progHours * 100) / 100,
      site_hours: Math.round(siteHours * 100) / 100,

      km: Math.round(a.km * 10) / 10,

      work_pay: Math.round(a.workPay * 100) / 100,
      travel_pay: Math.round(a.travelPay * 100) / 100,
      material: Math.round(a.material * 100) / 100,
      total_to_pay: Math.round(totalToPay * 100) / 100,

      // legacy fields
      hours: Math.round(a.hoursRounded * 100) / 100,
      hours_pay: Math.round(a.workPay * 100) / 100,
      km_pay: Math.round(a.travelPay * 100) / 100,
      total: Math.round(totalToPay * 100) / 100,

      paid: a.paid,
    });
  }
}
  // sort: unpaid first, newest first
  rows.sort((a, b) => {
    if (a.paid !== b.paid) return a.paid ? 1 : -1;
    if (a.day !== b.day) return a.day < b.day ? 1 : -1;
    return 0;
  });

  return json({ rows });
}
